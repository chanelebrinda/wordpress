<?php

//Custom post (event) configuration

define("IATEN_MENU_SLUG", "event");
define("IATEN_MENU_TITLE", 'WReservation');

// String of event configuration in setting menu

define('IATEN_WEEK_DAYS', array(__('Monday', 'instant-appointment'), __('Tuesday', 'instant-appointment'), __('Wednesday', 'instant-appointment'),  
__('Thursday', 'instant-appointment'), __('Friday', 'instant-appointment'), __('Saturday', 'instant-appointment'), 
__('Sunday', 'instant-appointment')));


define("IATEN_NOT_SPECIFY", __('Not Specify' , 'instant-appointment'));
define("IATEN_AT", __(" at ", 'instant-appointment'));

