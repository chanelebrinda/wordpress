<?php

// function WReservation_plugin_db_holidays_uninstall(){
// }
