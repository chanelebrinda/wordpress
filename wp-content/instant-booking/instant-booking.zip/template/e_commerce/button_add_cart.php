<div class="overlayca"></div>
    <div class="instBcart_content">
    
          <div id="shopping-cart" class="Insb_shopping-cart-container">

          <div class="instBcart__header">
              <div class="">
                <i class="icon"><svg width="24" height="29" viewBox="0 0 24 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M23 7.66406H1V27.8981H23V7.66406Z" stroke="black" stroke-miterlimit="10"></path>
                    <path d="M18.2246 12.8131V3.56548C18.2246 2.1485 16.8117 1 15.0687 1H9.26915C7.52624 1 6.11328 2.1485 6.11328 3.56548V12.811" stroke="black" stroke-miterlimit="10"></path>
                  </svg>
                </i>
                <div class="count_cart"></div>
              </div>
              <div class="title">
                    Votre panier
              </div> 
              <div id="cart__close"><i class="icon"><svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <line x1="1.35355" y1="0.646447" x2="16.7136" y2="16.0064" stroke="#303030"></line>
                    <line x1="1.29467" y1="15.3597" x2="16.6547" y2="0.63971" stroke="#303030"></line>
                  </svg>
                  </i>
              </div>
          </div>
            <table id="cart-content">
              <tbody></tbody>
            </table>
            <p class="total-container" id="total-price"> </p>
            <div class="cart_footer">
            
              <button type="submit" id="instant_checkout_button" class="cart-btn ">Checkout</button>
          
              <button  type="button" id="clear-cart" class="cart-btn ">Clear Cart</button>
            </div> 
          </div>
   </div> 
