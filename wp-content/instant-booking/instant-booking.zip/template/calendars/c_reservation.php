
  <div class="wrap content-wrapper">

  <div class="header-advance-area">
            <div class="container-fluid">
              <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="breadcome-list">
                          <div class="row">
                              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                 <div class=" ib-part1">
                                       <div class="ib-logo">
                                        <img width="100" src="<?php echo $logoInstant;?>" class="logo-big"> 
                                       </div> 
                                       <H4>Instant Booking</H4>
                                  </div> 
                              </div>
                              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                  <div class="breadcome-menu">
              <span class="bread-blod ariane"><?php _e(get_admin_page_title())?></span>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
        </div>
  
    <hr>
     <div class="ib-calendar-container">
        <!-- <div id="ib_loading"><img id="ib_loading-image" width="300" src="<?php echo $logoloading;?>" alt="Loading..." /></div> -->
        <div id="fs-calendar"></div> 
    </div>
     

</div>
<?php 
// ajaxselect_all_reservation();
?>