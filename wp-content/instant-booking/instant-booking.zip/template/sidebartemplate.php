<div class="to-top">
        <a class="btn btn-primary btn-customized-3" href="#" role="button">
            <i class="fas fa-arrow-up"></i> Top
        </a>
    </div>
    
    <div class="dark-light-buttons">
        <a class="btn btn-primary btn-customized-4 btn-customized-dark" href="#" role="button">Dark</a>
        <a class="btn btn-primary btn-customized-4 btn-customized-light" href="#" role="button">Light</a>
    </div>

</nav>
<!-- End sidebar -->

<!-- Dark overlay -->
<div class="overlay"></div>

<!-- Content -->
<div class="content">

    <!-- open sidebar menu -->
    <a class="btn btn-primary btn-customized open-menu" href="#" role="button">
        <i class="fas fa-align-left"></i> <span>Menu</span>
    </a>

</div>