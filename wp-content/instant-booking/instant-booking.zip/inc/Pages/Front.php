<?php

namespace Inc\Pages;

class Front{

 
}